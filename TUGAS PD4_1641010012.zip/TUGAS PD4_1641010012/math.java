class math {
    int a;
    int b;
    int tambah=0;
    int kurang=0;
    int kali=0;
    int bagi=0;
    int hasil;
        
    public math (){
	
    }
    public void penjumlahan(int a,int b){
    tambah = a+b;
	System.out.println("Hasil dari Pertambahan : "+a+" + "+b+" = "+tambah);
	}

    public void perkalian (int a,int b) {
	kali = a*b;
	System.out.println("Hasil dari Perkalian  : "+a+" * "+b+" = "+kali);
	}

    public void pembagian (int a,int b) {
	bagi = a/b;
	System.out.println("Hasil dari Pembagian : "+a+" / "+b+" = "+bagi);
	}
    public void modulus(int a, int b){
	hasil = a % b;
	System.out.println("Hasil dari Modulus : "+hasil);
	}
}