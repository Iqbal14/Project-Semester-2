public class bank{
int saldo,simpanUang,ambilUang;
public bank(int saldo){
	System.out.println("");
	this.saldo=saldo;
	System.out.println("Selamat datang di Bank ABC"+"\nSaldo saat ini : Rp "+saldo);
	System.out.println("");
}

void simpanUang(int simpanUang){
	System.out.println("");
	saldo=saldo+simpanUang;
	System.out.println("Simpan uang    : Rp "+simpanUang+"\nSaldo saat ini : Rp "+saldo);
	System.out.println("");
}
	
void ambilUang(int ambilUang){
	System.out.println("");
	saldo=saldo-ambilUang;
	System.out.println("Ambil uang     : Rp "+ambilUang+"\nSaldo saat ini : Rp "+saldo);
	System.out.println("");
}

}