public class MathGabungan{

    public static void main(String[] args) {
	math hitung = new math();

	hitung.penjumlahan(20,20);
	hitung.perkalian(10,20);
	hitung.modulus(10,20);
    }
}