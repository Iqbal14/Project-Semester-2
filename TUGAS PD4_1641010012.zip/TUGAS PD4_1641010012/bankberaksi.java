public class bankberaksi{
public static void main(String[]args){
	bank banksaya = new bank (100000);
	banksaya.simpanUang(500000);
	banksaya.ambilUang(150000);

}
}