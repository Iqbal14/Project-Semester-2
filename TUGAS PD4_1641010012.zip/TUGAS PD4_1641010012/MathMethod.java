class mathMethod extends math {
	// method
	public void moduluslagi(int a, int b){
	hasil = a % b;
	System.out.println("Hasil dari Modulus : "+hasil);
	}		
}